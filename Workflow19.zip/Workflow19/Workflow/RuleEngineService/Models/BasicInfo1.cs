﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RuleEngineService.Models
{
    public class BasicInfo1
    {
        public string orders { get; set; }
        public string items { get; set; }
        public string project { get; set; }
    }
}
