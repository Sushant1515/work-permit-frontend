﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RuleEngineService.Models
{
    public class OrdeInfo
    {
        public string ordername { get; set; }

        public int qty { get; set; }

        public decimal amount { get; set; }
    }
}
