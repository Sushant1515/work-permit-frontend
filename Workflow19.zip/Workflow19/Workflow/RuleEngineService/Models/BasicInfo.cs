﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RuleEngineService.Models
{
    public class BasicInfo
    {
        public string country { get; set; }
        public string state { get; set; }
        public string cityname { get; set; }
        public string picode { get; set; }
    }
}
