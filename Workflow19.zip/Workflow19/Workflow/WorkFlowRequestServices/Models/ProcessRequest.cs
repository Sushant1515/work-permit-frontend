﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkFlowRequestServices.Models
{
    public class ProcessRequest
    {
        public int iRequest_Id { get; set; }
        public int iStatus_Id { get; set; }
    }
}
