﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WorkFlowEntry.Models
{
    public static class WebApiUrl
    {
        public static string webapi = "https://datausa.io/api/data?drilldowns=Nation&measures=Population";
    }
}
